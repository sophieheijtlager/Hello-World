<template>
<div class="container">
  <!-- Items -->
  <button class="item">
    <v-icon>mdi-bookmark-outline</v-icon>
    <p>Scheduled</p>
  </button>

  <button class="item">
    <v-icon>mdi-check-circle</v-icon>
    <p>Completed</p>
  </button>

 <button class="item">
    <v-icon>mdi-grid</v-icon>
    <p>Knowledge base</p>
  </button>

 <button class="item">
    <v-icon>mdi-cog</v-icon>
    <p>Settings</p>
  </button>
</div>
</template>

<script setup>
</script>

<style scoped>
  .container {
    margin-block-start: 85px;
    display: grid;
    justify-content: center;
    gap: 1em;
    padding: 1em;
    background-color: rgb(255, 255, 255);
  }

  .v-icon {
    font-size: 150px;
    color: rgba(20,27,31);
  }

  .item {
    height: 275px;
    inline-size: 45vw;
    background-color: rgb(255, 255, 255);
    box-shadow: 1px 1px 3px #888888;
    border-radius: 10px;
  }

  .item:nth-of-type(2) {
    grid-area: 1/2/1/2;
  }

  p {
    color: rgba(20,27,31);
  }

</style>
