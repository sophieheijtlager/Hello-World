<script setup>
</script>


  <template>
  <v-layout class="overflow-visible" style="height: 56px;">
    <v-bottom-navigation grow>
      <v-btn>
        <v-icon>mdi-wrench</v-icon>
        Active Task
      </v-btn>

      <v-btn>
        <v-icon>mdi-magnify</v-icon>
        Search
      </v-btn>

      <v-btn>
        <v-icon>mdi-alert-circle</v-icon>
        Information
      </v-btn>
      
    </v-bottom-navigation>
  </v-layout>
</template>


<style scoped>
</style>