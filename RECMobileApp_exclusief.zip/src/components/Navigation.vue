<template>
    <!-- TOP CONS BAR -->
    <v-system-bar>
      <v-icon>mdi-square</v-icon>
      <v-icon>mdi-circle</v-icon>
      <v-icon>mdi-triangle</v-icon>
    </v-system-bar>

    <!-- NAVBAR -->
    <v-app-bar>

      <!-- Logo  -->
        <v-app-bar-title>
          <img src="/src/assets/mainLogoREC.svg" alt="RealEstateCareLogo">
        </v-app-bar-title>

      <!-- Bell Icon -->
      <v-btn icon>
        <v-icon>mdi-bell</v-icon>
      </v-btn>

      <!-- Settings Icon -->
      <v-btn icon>
        <v-icon>mdi-cog</v-icon>
      </v-btn>
 
    </v-app-bar>
</template>

<script setup>
</script>

<style scoped>  
.v-app-bar-title img {
  inline-size: 200px;
  display: flex;
}

.v-system-bar {
  background-color: rgba(0,170,162);
}

.v-img {
  background-color: rgb(50, 104, 101);
}
</style>
